import { MockModel } from './MockModel';
import type { QualityModel } from './ModelInterface';
import type { SensorReading, ImageFeatures, ModelOutput } from '../types';

/**
 * Singleton model instance.
 *
 * To use a real ONNX model:
 * 1. import { OnnxModel } from './OnnxModel'
 * 2. Change: const model: QualityModel = await OnnxModel.load('/model.onnx')
 * 3. Make predict() async and await it at call sites
 */
const model: QualityModel = new MockModel();

/**
 * Run quality prediction on a sensor reading.
 * Single entry point for all model inference throughout the app.
 */
export function predict(
  reading: SensorReading,
  sampleType: 'feed' | 'silage',
  imageFeatures?: ImageFeatures
): ModelOutput {
  return model.predict(reading, sampleType, imageFeatures);
}
